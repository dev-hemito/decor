﻿<!DOCTYPE html>
<html lang="en">
<!-- head start -->

<head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Decor Stories</title>
    <!-- Favicon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/ionicons.css">
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<!-- head end -->

<body>

    <?php include("header.php"); ?>

    <section class="hero-section">
        <div class="hero-slider">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <!-- swiper-slide start -->
                    <div class="hero-slide-item slider-height1 swiper-slide slide-bg1">
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="hero-slide-content">
                                        <p class="text text-white animated">
                                            new collection
                                        </p>
                                        <br>
                                        <h2 class="title text-dark delay1 animated">
                                            Custom Wooden
                                        </h2>
                                        <br>
                                        <h2 class="title text-dark delay2 animated">
                                            Tables Decor
                                        </h2>
                                        <br>
                                        <a href="#!" class="btn animated btn-outline-dark">Shop
                                            Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- swiper-slide end-->

                    <!-- swiper-slide start -->
                    <div class="hero-slide-item slider-height1 swiper-slide slide-bg2">
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="hero-slide-content">
                                        <p class="text text-white animated">
                                            our new design
                                        </p>
                                        <br>
                                        <h2 class="title text-dark delay1 animated">
                                            Capsule Soft
                                        </h2>
                                        <br>
                                        <h2 class="title text-dark delay2 animated">
                                            Seating
                                        </h2>
                                        <br>
                                        <a href="shop" class="btn animated btn-outline-dark">Shop
                                            Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- swiper-slide end-->
                </div>
            </div>

            <!-- Add Pagination -->
            <div class="swiper-pagination"></div>
            <!-- swiper navigation -->
            <div class="d-none d-lg-block">
                <div class="swiper-button-prev">
                    <i class="ion-chevron-left"></i>
                </div>
                <div class="swiper-button-next">
                    <i class="ion-chevron-right"></i>
                </div>
            </div>
        </div>
    </section>


    <section class="banner-section section-padding-bottom">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4 g-0 col-md-6">
                    <div class="category-list">
                        <img src="assets/images/category/furniture.webp" alt="">
                        <h4>Furniture</h4>
                        <div class="overlay">
                            <h5>Furniture</h5>
                            <p>Explore a wide range of furniture for every room.</p>
                            <a href="shop" class="mx-auto">View Products</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 g-0 col-md-6">
                    <div class="category-list">
                        <img src="assets/images/category/lighting.webp" alt="">
                        <h4>Lighting</h4>
                        <div class="overlay">
                            <h5>Lighting</h5>
                            <p>Ambiance through varied lighting solutions.</p>
                            <a href="shop" class="mx-auto">View Products</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 g-0 col-md-6">
                    <div class="category-list">
                        <img src="assets/images/category/wall-decor.webp" alt="">
                        <h4>Wall Decor</h4>
                        <div class="overlay">
                            <h5>Wall Decor</h5>
                            <p>Enhance walls with art, mirrors, and clocks.</p>
                            <a href="shop" class="mx-auto">View Products</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 g-0 col-md-6">
                    <div class="category-list">
                        <img src="assets/images/category/home-textiles.webp" alt="">
                        <h4>Home Textiles</h4>
                        <div class="overlay">
                            <h5>Home Textiles</h5>
                            <p>Comfort and style with our textile collection.</p>
                            <a href="shop" class="mx-auto">View Products</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 g-0 col-md-6">
                    <div class="category-list">
                        <img src="assets/images/category/kitchen-dining.webp" alt="">
                        <h4>Kitchen and Dining</h4>
                        <div class="overlay">
                            <h5>Kitchen and Dining</h5>
                            <p>Essentials for modern kitchens and dining areas.</p>
                            <a href="shop" class="mx-auto">View Products</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 g-0 col-md-6">
                    <div class="category-list">
                        <img src="assets/images/category/bathroom-accessories.webp" alt="">
                        <h4>Bathroom Accessories</h4>
                        <div class="overlay">
                            <h5>Bathroom Accessories</h5>
                            <p>Functional and aesthetic bathroom enhancements.</p>
                            <a href="shop" class="mx-auto">View Products</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 g-0 col-md-6">
                    <div class="category-list">
                        <img src="assets/images/category/home-office.webp" alt="">
                        <h4>Home Office</h4>
                        <div class="overlay">
                            <h5>Home Office</h5>
                            <p>Optimize your workspace with ergonomic solutions.</p>
                            <a href="shop" class="mx-auto">View Products</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 g-0 col-md-6">
                    <div class="category-list">
                        <img src="assets/images/category/flooring.webp" alt="">
                        <h4>Flooring</h4>
                        <div class="overlay">
                            <h5>Flooring</h5>
                            <p>Diverse flooring options for every space.</p>
                            <a href="shop" class="mx-auto">View Products</a>
                        </div>
                    </div>
                </div>



                <div class="col-lg-4 g-0 col-md-6">
                    <div class="category-list">
                        <img src="assets/images/category/decorative-accessories.webp" alt="">
                        <h4>Decorative Accessories</h4>
                        <div class="overlay">
                            <h5>Decorative Accessories</h5>
                            <p>Unique accessories to personalize your space.</p>
                            <a href="shop" class="mx-auto">View Products</a>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>



    <!-- product tab section start -->
    <section class="product-tab-section section-padding-bottom">
        <div class="container">
            <div class="row">
                <!-- tabs liks start -->
                <div class="col-12">
                    <ul class="nav nav-pills product-tab-nav" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#pills-arrivals">New
                                Arrivals</button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-seller">Best
                                Sellers</button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-onsale">On
                                Sale</button>
                        </li>
                    </ul>
                </div>
                <!-- tabs liks end -->
                <div class="col-12">
                    <div class="tab-content" id="pills-tabContent">
                        <!-- tab-pane one -->
                        <div class="tab-pane fade show active" id="pills-arrivals">

                            <div class="product-tab-list swiper-arrow arrow-position-center">
                                <!-- Slider main container -->
                                <div class="swiper-container">
                                    <!-- Additional required wrapper -->
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-danger">sale!</span>
                                                        <img src="assets/images/products/product1.jpg" alt="image_not_found">
                                                    </a>

                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">3 Tier
                                                                Wood With Metal Shelf</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button class="product-btn">Order Now</button>
                                                        </div>
                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">


                                                        <li class="product-thumb product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>

                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product2.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">63in.
                                                                White Stucco Floor Lamp</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹85.00</del> <span class="new-price">₹60.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-danger">sale!</span>
                                                        <img src="assets/images/products/product3.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">68in.
                                                                Bronze Metal Coat Rack</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹85.00</del> <span class="new-price">₹60.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product4.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Emmy
                                                                Green Floral Wood Leg</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-warning">hot!</span>
                                                        <img src="assets/images/products/product5.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Gold
                                                                Circle Mirrored Shelf Bar Cart</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product6.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Gold
                                                                Metal Clothing Rack With</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-warning">hot</span>
                                                        <img src="assets/images/products/product7.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Gold
                                                                Metal Fox Design Trinket Tray</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-danger">sale!</span>
                                                        <img src="assets/images/products/product8.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Heirloom
                                                                Gold Metal Folding Shelf</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product9.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Parkview
                                                                5 Tier Metal & Wood</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-warning">hot</span>
                                                        <img src="assets/images/products/product10.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Rabbit
                                                                Grey Faux Fur Pouf</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                    </div>
                                </div>
                                <!-- If we need navigation buttons -->
                                <div class="product-tab-list swiper-button-prev"></div>
                                <div class="product-tab-list swiper-button-next"></div>
                            </div>
                        </div>
                        <!-- tab-pane end -->
                        <!-- tab-pane two -->
                        <div class="tab-pane fade" id="pills-seller">
                            <div class="product-tab-list swiper-arrow arrow-position-center">
                                <!-- Slider main container -->
                                <div class="swiper-container">
                                    <!-- Additional required wrapper -->
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-danger">sale!</span>
                                                        <img src="assets/images/products/product1.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">3 Tier
                                                                Wood With Metal Shelf</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product2.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">63in.
                                                                White Stucco Floor Lamp</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price">₹585.00</h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-danger">sale!</span>
                                                        <img src="assets/images/products/product3.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">68in.
                                                                Bronze Metal Coat Rack</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price">₹585.00 - ₹560.00</h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product4.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Emmy
                                                                Green Floral Wood Leg</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-warning">hot!</span>
                                                        <img src="assets/images/products/product5.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Gold
                                                                Circle Mirrored Shelf Bar Cart</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product6.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Gold
                                                                Metal Clothing Rack With</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-warning">hot</span>
                                                        <img src="assets/images/products/product7.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Gold
                                                                Metal Fox Design Trinket Tray</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-danger">sale!</span>
                                                        <img src="assets/images/products/product8.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Heirloom
                                                                Gold Metal Folding Shelf</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product9.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Parkview
                                                                5 Tier Metal & Wood</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-warning">hot</span>
                                                        <img src="assets/images/products/product10.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Rabbit
                                                                Grey Faux Fur Pouf</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                    </div>
                                </div>
                                <!-- If we need navigation buttons -->
                                <div class="product-tab-list swiper-button-prev"></div>
                                <div class="product-tab-list swiper-button-next"></div>
                            </div>
                        </div>
                        <!-- tab-pane end -->
                        <!-- tab-pane three -->
                        <div class="tab-pane fade" id="pills-onsale">
                            <div class="product-tab-list swiper-arrow arrow-position-center">
                                <!-- Slider main container -->
                                <div class="swiper-container">
                                    <!-- Additional required wrapper -->
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-danger">sale!</span>
                                                        <img src="assets/images/products/product1.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">3 Tier
                                                                Wood With Metal Shelf</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product2.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">63in.
                                                                White Stucco Floor Lamp</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price">₹585.00</h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-danger">sale!</span>
                                                        <img src="assets/images/products/product3.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">68in.
                                                                Bronze Metal Coat Rack</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price">₹585.00 - ₹560.00</h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product4.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Emmy
                                                                Green Floral Wood Leg</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-warning">hot!</span>
                                                        <img src="assets/images/products/product5.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Gold
                                                                Circle Mirrored Shelf Bar Cart</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product6.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Gold
                                                                Metal Clothing Rack With</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-warning">hot</span>
                                                        <img src="assets/images/products/product7.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Gold
                                                                Metal Fox Design Trinket Tray</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-danger">sale!</span>
                                                        <img src="assets/images/products/product8.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Heirloom
                                                                Gold Metal Folding Shelf</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                        <div class="swiper-slide">
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-success">new</span>
                                                        <img src="assets/images/products/product9.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Parkview
                                                                5 Tier Metal & Wood</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                            <div class="product-list">
                                                <div class="product-card">
                                                    <a href="#!product" class="product-thumb">
                                                        <span class="onsale bg-warning">hot</span>
                                                        <img src="assets/images/products/product10.jpg" alt="image_not_found">
                                                    </a>
                                                    <!-- thumb end -->
                                                    <div class="product-content">
                                                        <h4><a href="#!product" class="product-title">Rabbit
                                                                Grey Faux Fur Pouf</a></h4>
                                                        <div class="product-group">
                                                            <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                            <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                        </div>

                                                    </div>
                                                    <!-- actions  -->
                                                    <ul class="actions actions-verticale">

                                                        <li class="product-thumb action quick-view">
                                                            <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                        </li>

                                                        <li class="action compare">
                                                            <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- product list end -->
                                        </div>
                                        <!-- swiper-slide end -->
                                    </div>
                                </div>
                                <!-- If we need navigation buttons -->
                                <div class="product-tab-list swiper-button-prev"></div>
                                <div class="product-tab-list swiper-button-next"></div>
                            </div>
                        </div>
                        <!-- tab-pane end -->
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- product tab section end -->

    <!-- decoration slider start -->

    <div class="decoration-slider-section bg-light section-padding-top section-padding-bottom">
        <!-- section title section -->
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <section class="section-title text-center">
                        <h3 class="title">Shop By Room</h3>
                    </section>
                </div>
            </div>
        </div>
        <!-- section title section -->

        <div class="container-fluid px-xl-0">
            <div class="decoration-slider-active swiper-arrow arrow-position-center-fixed">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="decoration">
                                <a class="decoration-thumb" href="#!room">
                                    <img src="assets/images/decoration/1.jpg" alt="image_not_found">
                                </a>
                                <div class="decoration-content">
                                    <h3 class="decoration-title">Kitchen Room</h3>
                                    <a href="shop" class="btn btn-outline-dark">Discover Now</a>
                                </div>
                            </div>
                        </div>
                        <!-- swiper-slide end -->
                        <div class="swiper-slide">
                            <div class="decoration">
                                <a class="decoration-thumb" href="#!room">
                                    <img src="assets/images/decoration/2.jpg" alt="image_not_found">
                                </a>
                                <div class="decoration-content">
                                    <h3 class="decoration-title">Living Room</h3>
                                    <a href="shop" class="btn btn-outline-dark">Discover Now</a>
                                </div>
                            </div>
                        </div>
                        <!-- swiper-slide end -->
                        <div class="swiper-slide">
                            <div class="decoration">
                                <a class="decoration-thumb" href="#!room">
                                    <img src="assets/images/decoration/3.jpg" alt="image_not_found">
                                </a>
                                <div class="decoration-content">
                                    <h3 class="decoration-title">Bedroom</h3>
                                    <a href="shop" class="btn btn-outline-dark">Discover Now</a>
                                </div>
                            </div>
                        </div>
                        <!-- swiper-slide end -->
                    </div>
                </div>
                <!-- If we need navigation buttons -->
                <div class="decoration-slider-active swiper-button-prev"></div>
                <div class="decoration-slider-active swiper-button-next"></div>
            </div>
        </div>
    </div>
    <!-- decoration slider end -->
    <div class="featured-product-section  section-padding-top section-padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <section class="section-title text-center">
                        <h3 class="title">Featured Products</h3>
                    </section>
                </div>
                <div class="col-12">
                    <div class="featured-product swiper-arrow arrow-position-center">
                        <!-- Slider main container -->
                        <div class="swiper-container">
                            <!-- Additional required wrapper -->
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="product-list">
                                        <div class="product-card">
                                            <a href="#!room" class="product-thumb">
                                                <span class="onsale bg-danger">sale!</span>
                                                <img src="assets/images/products/product1.jpg" alt="image_not_found">
                                            </a>
                                            <!-- thumb end -->
                                            <div class="product-content">
                                                <h4><a href="#!room" class="product-title">3 Tier
                                                        Wood With Metal Shelf</a></h4>
                                                <div class="product-group">
                                                    <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                </div>

                                            </div>
                                            <!-- actions  -->
                                            <ul class="actions actions-verticale">

                                                <li class="product-thumb action quick-view">
                                                    <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                </li>

                                                <li class="action compare">
                                                    <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                    <!-- product list end -->

                                </div>
                                <!-- swiper-slide end -->
                                <div class="swiper-slide">
                                    <div class="product-list">
                                        <div class="product-card">
                                            <a href="#!room" class="product-thumb">
                                                <span class="onsale bg-danger">sale!</span>
                                                <img src="assets/images/products/product3.jpg" alt="image_not_found">
                                            </a>
                                            <!-- thumb end -->
                                            <div class="product-content">
                                                <h4><a href="#!room" class="product-title">68in.
                                                        Bronze Metal Coat Rack</a></h4>
                                                <div class="product-group">
                                                    <h5 class="product-price">₹585.00 - ₹560.00</h5>
                                                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                </div>

                                            </div>
                                            <!-- actions  -->
                                            <ul class="actions actions-verticale">

                                                <li class="product-thumb action quick-view">
                                                    <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                </li>

                                                <li class="action compare">
                                                    <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                    <!-- product list end -->

                                </div>
                                <!-- swiper-slide end -->
                                <div class="swiper-slide">
                                    <div class="product-list">
                                        <div class="product-card">
                                            <a href="#!room" class="product-thumb">
                                                <span class="onsale bg-warning">hot!</span>
                                                <img src="assets/images/products/product5.jpg" alt="image_not_found">
                                            </a>
                                            <!-- thumb end -->
                                            <div class="product-content">
                                                <h4><a href="#!room" class="product-title">Gold
                                                        Circle Mirrored Shelf Bar Cart</a></h4>
                                                <div class="product-group">
                                                    <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                </div>

                                            </div>
                                            <!-- actions  -->
                                            <ul class="actions actions-verticale">

                                                <li class="product-thumb action quick-view">
                                                    <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                </li>

                                                <li class="action compare">
                                                    <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                    <!-- product list end -->

                                </div>
                                <!-- swiper-slide end -->
                                <div class="swiper-slide">
                                    <div class="product-list">
                                        <div class="product-card">
                                            <a href="#!room" class="product-thumb">
                                                <span class="onsale bg-warning">hot</span>
                                                <img src="assets/images/products/product7.jpg" alt="image_not_found">
                                            </a>
                                            <!-- thumb end -->
                                            <div class="product-content">
                                                <h4><a href="#!room" class="product-title">Gold
                                                        Metal Fox Design Trinket Tray</a></h4>
                                                <div class="product-group">
                                                    <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                </div>

                                            </div>
                                            <!-- actions  -->
                                            <ul class="actions actions-verticale">

                                                <li class="product-thumb action quick-view">
                                                    <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                </li>

                                                <li class="action compare">
                                                    <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                    <!-- product list end -->

                                </div>
                                <!-- swiper-slide end -->
                                <div class="swiper-slide">
                                    <div class="product-list">
                                        <div class="product-card">
                                            <a href="#!room" class="product-thumb">
                                                <span class="onsale bg-success">new</span>
                                                <img src="assets/images/products/product9.jpg" alt="image_not_found">
                                            </a>
                                            <!-- thumb end -->
                                            <div class="product-content">
                                                <h4><a href="#!room" class="product-title">Parkview
                                                        5 Tier Metal & Wood</a>
                                                </h4>
                                                <div class="product-group">
                                                    <h5 class="product-price"><del class="old-price">₹585.00</del> <span class="new-price">₹560.00</span></h5>
                                                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" class="product-btn">Order Now</button>
                                                </div>

                                            </div>
                                            <!-- actions  -->
                                            <ul class="actions actions-verticale">

                                                <li class="product-thumb action quick-view">
                                                    <button data-bs-toggle="modal" data-bs-target="#product-modal"><i class="far fa-eye"></i></button>
                                                </li>

                                                <li class="action compare">
                                                    <button class="whatsapp-order"><i class="fab fa-whatsapp"></i></button>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                    <!-- product list end -->
                                </div>
                                <!-- swiper-slide end -->
                            </div>
                        </div>
                        <!-- If we need navigation buttons -->
                        <div class="featured-product swiper-button-prev"></div>
                        <div class="featured-product swiper-button-next"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- featured product end -->



    <?php include("footer.php"); ?>