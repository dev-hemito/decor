<section class="menu">
	<ul>
	<li><img src="../assets/images/decor-logo.png" alt="" style="max-width: 50%;margin-left: -10px;"></li>
		<li><a href="index.php">Add Product</a></li>
		<li><a href="product-view.php">View Products</a></li>
		<li><a href="product-gallery.php">Product Gallery</a></li>
		<li><a href="category.php">Category</a></li>
		<li><a href="size.php">Size</a></li>
		<li><a href="material.php">Material</a></li>
		<li><a href="color.php">Color</a></li>
		<li><a href="logout.php" class="text-danger">Logout</a></li>
	</ul>
</section>