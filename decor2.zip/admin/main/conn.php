<?php

$conn = mysqli_connect('localhost', 'root' ,'' , 'foyer');
  
  // Check if connection succeeded
  if(!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
  }

  ?>
  