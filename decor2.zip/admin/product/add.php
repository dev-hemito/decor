<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

include('../main/conn.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize it
    $productName = !empty($_POST['product-name']) ? htmlspecialchars($_POST['product-name'], ENT_QUOTES, 'UTF-8') : null;
    $metaTitle = !empty($_POST['meta-title']) ? htmlspecialchars($_POST['meta-title'], ENT_QUOTES, 'UTF-8') : null;
    $metaDescription = !empty($_POST['meta-description']) ? htmlspecialchars($_POST['meta-description'], ENT_QUOTES, 'UTF-8') : null;
    $actualPrice = !empty($_POST['actual-price']) ? $_POST['actual-price'] : null;
    $salePrice = !empty($_POST['sale-price']) ? $_POST['sale-price'] : null;
    $details = !empty($_POST['details']) ? htmlspecialchars($_POST['details'], ENT_QUOTES, 'UTF-8') : null;
    $tags = !empty($_POST['tags']) ? htmlspecialchars($_POST['tags'], ENT_QUOTES, 'UTF-8') : null;

    $categoryId = !empty($_POST['category']) ? $_POST['category'] : null;
    $sizeId = !empty($_POST['size']) ? $_POST['size'] : null;
    $materialId = !empty($_POST['material']) ? $_POST['material'] : null;
    $colorId = !empty($_POST['color']) ? $_POST['color'] : null;


    $typeArray = !empty($_POST['type']) ? $_POST['type'] : [];
    $typeValues = array_map(function($value) {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }, $typeArray);
    $typeValue = implode('&', $typeValues);
    


    $status = !empty($_POST['status']) ? $_POST['status'] : null;


    $image = null;  // Handle image upload separately

    // Handle image upload (similar to your existing code)
    if (isset($_FILES['image'])) {
        $uploadDir = '../images/';
        $file = $_FILES['image'];
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $uniqueFileName = time() . '_' . str_replace(' ', '_', $fileName);
        $targetFilePath = $uploadDir . $uniqueFileName;

        if (move_uploaded_file($fileTmpName, $targetFilePath)) {
            $image = $uniqueFileName;
        } else {
            $error = "Error uploading the image.";
        }
    }



    // Insert product data into the database
    $sql = "INSERT INTO products (product_name, meta_title, meta_description, actual_price, sale_price, details, tags, image, category_id, size_id, material_id, color_id, type, status)
VALUES ('$productName', '$metaTitle', '$metaDescription', '$actualPrice', '$salePrice', '$details', '$tags', '$image', $categoryId, $sizeId, $materialId, $colorId, '$typeValue', '$status')";


    if (mysqli_query($conn, $sql)) {
        echo "product added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
