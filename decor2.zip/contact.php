<!DOCTYPE html>
<html lang="en">
<!-- head start -->

<head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Decor Stories</title>
    <!-- Favicon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/ionicons.css">
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<!-- head end -->

<body>

    <?php include("header.php"); ?>

    <!-- main content start -->
    <!-- bread crumb section start -->
    <nav class="breadcrumb-section breadcrumb-bg1">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2 class="bread-crumb-title">Contact</h2>
                    <ol class="breadcrumb bg-transparent m-0 p-0 justify-content-center align-items-center">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Contact</li>
                    </ol>
                </div>
            </div>
        </div>
    </nav>
    <!-- bread crumb section end -->

    <section class="contact-section section-padding-bottom">
        <div class="container">
            <div class="row mb-n4">
                <div class="col-lg-3 mb-4">
                    <!-- contact-title-section start -->
                    <div class="contact-title-section">
                        <h3 class="title">Contact Us</h3>
                    </div>
                    <!-- contact-title-section end -->
                    <div class="contact-address">
                        <!-- address-list start -->
                        <div class="address-list">
                            <h4 class="title"><span class="ion-ios-home"></span>Address</h4>
                            <p>
                                your Address goes here
                            </p>
                        </div>
                        <!-- address-list end -->
                        <!-- address-list start -->
                        <div class="address-list">
                            <h4 class="title"><span class="ion-ios-telephone"></span>Email</h4>
                            <ul>
                                <li>
                                    <a class="mailto" href="mailto:info@example.com">info@example.com</a>
                                </li>
                                <li>
                                    <a class="mailto" href="mailto:www.example.com">www.example.com</a>
                                </li>
                            </ul>
                        </div>
                        <!-- address-list end -->
                        <!-- address-list start -->
                        <div class="address-list">
                            <h4 class="title"><span class="ion-email"></span> Phone</h4>
                            <ul>
                                <li>
                                    <a class="phone-number" href="tel:+12345678987">+12345 678 987</a>
                                </li>
                                <li>
                                    <a class="phone-number" href="tel:+98745612321">+98745 612 321</a>
                                </li>
                            </ul>
                        </div>
                        <!-- address-list end -->

                    </div>
                </div>
                <div class="col-lg-8 offset-lg-1 mb-4">
                    <!-- contact-title-section start -->
                    <div class="contact-title-section">
                        <h3 class="title">Tell Us Your Message</h3>
                    </div>
                    <!-- contact-title-section end -->

                    <form id="contactForm" class="row contact-us-form appointment-form query_form" action="#" method="POST" novalidate="novalidate">

                        <div class="col-12">
                            <label class="form-label" for="name">Your Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Your Name*">
                        </div>
                        <!-- Name filed end -->
                        <div class="col-12">
                            <label class="form-label" for="email">Your Email</label>
                            <input type="text" class="form-control" id="email" name="email" placeholder="Your Email*">
                        </div>
                        <!-- email filed end -->
                        <div class="col-12">
                            <label class="form-label" for="subject">Subject</label>
                            <input type="text" class="form-control" id="subject" name="subject" placeholder="Your subject*">
                        </div>
                        <!-- Subject filed end -->
                        <div class="col-12">
                            <label class="form-label" for="massage">Your Message</label>
                            <textarea class="form-control massage-control" name="massage" id="massage" cols="30" rows="10" placeholder="Message"></textarea>
                        </div>
                        <!-- Message filed end -->
                        <div class="col-12">
                            <button id="contactSubmit" type="button" class="btn btn-dark" onclick="Send()">Send Message</button>
                            <p class="form-message mt-3"></p>
                        </div>
                    </form>


                    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
                    <script src="https://smtpjs.com/v3/smtp.js"></script>
                    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


                    <script>
                        function Send() {
                            event.preventDefault();

                            var name = document.getElementById("name").value;
                            var email = document.getElementById("email").value;
                            var subject = document.getElementById("subject").value;
                            var msg = document.getElementById("massage").value;

                            // Validation: Check if any of the required fields is empty
                            if (!name || !email || !subject || !msg) {
                                swal("Error", "Please fill in all the required fields.", "error");
                                return; // Stop execution if validation fails
                            }

                            // Update button text
                            $('.query_form .btn').text('Sending...');

                            var body = "Name: " + name + "<br/>Email: " + email + "<br/>Subject: " + subject +
                                "<br/>Message: " + msg;

                            Email.send({
                                Host: "smtp.elasticemail.com",
                                Username: "website.enquiry.mailer@gmail.com",
                                Password: "88A13DA696E1DA754571F28C500545642B31",
                                To: 'hisham1off@gmail.com, website.enquiry.mailer@gmail.com', // Add the second email address here
                                From: "website.enquiry.mailer@gmail.com",
                                Subject: "Decor Stories Website Enquiry",
                                Body: body
                            }).then(function(message) {
                                // Handle email sending success or failure if needed
                                // Assuming the button should be updated here as well
                                $('.query_form .btn').text('Message sent');
                                $('.query_form')[0].reset();
                            });
                        }
                    </script>

                </div>
            </div>
        </div>
    </section>

    <div class="map" style="margin-bottom: -8px;">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3929.8272256505734!2d76.31727347397059!3d9.948329073923853!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b0872b7e55c29ef%3A0x564c6f46425d9786!2sHemito%20Digital%20Pvt%20Ltd!5e0!3m2!1sen!2sin!4v1705044251738!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <!-- main content end -->

    <?php include("footer.php"); ?>